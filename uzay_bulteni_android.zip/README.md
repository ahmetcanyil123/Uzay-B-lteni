# 🚀 Uzay Bülteni — Saf Java Android Uygulaması (APK)

Bu proje, **NASA, SpaceX, Space.com, Universe Today, Uzay.org, Evrim Ağacı ve TÜBİTAK Bilim Genç** kaynaklarını canlı tarayıp güncel uzay raporunu **doğrudan uygulamanın kendi ekranında** gösteren, tamamen **Java** ile yazılmış yerli bir Android uygulamasıdır.

## 📱 Özellikler
- **Rapor Doğrudan Uygulama İçinde Gösterilir:** Başka dosya veya tarayıcı açmaya gerek kalmadan, uygulama içindeki koyu uzay temalı ekranda 🔭 **Gök Olayları**, ⭐ **1–10 Puanlı Haberler** ve tıklanabilir linkler yer alır.
- **Saf Java Ağ Motoru (`RssFetcher` + `GeminiClient`):** RSS beslemelerini ve Gemini API çağrılarını doğrudan Android Java üzerinden yapar; 404/503 yoğunluğunda otomatik olarak yedek modellere (`gemini-3.1-flash-lite`, `gemini-flash-latest`, `gemini-3.8-flash`, `gemini-3.5-flash`) geçer.
- **Akıllı Önbellek:** Oluşturulan son rapor cihazda saklanır; uygulamayı tekrar açtığınızda bekletmeden ekrana gelir.
- **Paylaş & Ayarlar:** Tek dokunuşla WhatsApp/Telegram üzerinden paylaşabilir, ⚙️ ayarlar butonundan API anahtarınızı güncelleyebilirsiniz.

## 📲 GitHub'dan APK Oluşturma ve İndirme
1. GitHub'da yeni bir repo oluşturun (örn: `uzay-bulteni-app`).
2. `uzay_bulteni_android.zip` içindeki dosyaları (veya doğrudan bu klasördeki tüm dosyaları) reponuza yükleyin.
3. Üstteki **Actions** sekmesinde **Build Uzay Bulteni APK** otomatik çalışacaktır (~2 dakika).
4. İşlem bitince sağdaki **Releases** bölümünden **`UzayBulteni.apk`** dosyasını telefonunuza indirip kurun!
