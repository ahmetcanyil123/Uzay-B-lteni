package com.uzay.bulteni;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "uzay_bulteni_prefs";
    private static final String KEY_API = "gemini_api_key";
    private static final String KEY_LAST_CHECK = "last_check_date";
    private static final String KEY_LAST_REPORT = "last_report_md";
    private static final String DEFAULT_API_KEY = "";

    private Button btnGenerate;
    private ImageButton btnShare;
    private ImageButton btnSettings;
    private LinearLayout layoutProgress;
    private TextView tvStatus;
    private TextView tvLastCheck;
    private WebView reportWebView;

    private SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private String currentReportMarkdown = "";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        btnGenerate = findViewById(R.id.btnGenerate);
        btnShare = findViewById(R.id.btnShare);
        btnSettings = findViewById(R.id.btnSettings);
        layoutProgress = findViewById(R.id.layoutProgress);
        tvStatus = findViewById(R.id.tvStatus);
        tvLastCheck = findViewById(R.id.tvLastCheck);
        reportWebView = findViewById(R.id.reportWebView);

        setupWebView();
        loadSavedReport();

        btnGenerate.setOnClickListener(v -> startBulletinGeneration());
        btnShare.setOnClickListener(v -> shareReport());
        btnSettings.setOnClickListener(v -> showSettingsDialog());
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = reportWebView.getSettings();
        settings.setJavaScriptEnabled(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        reportWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri != null && ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme()))) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });
    }

    private void loadSavedReport() {
        String savedReport = prefs.getString(KEY_LAST_REPORT, "");
        String lastCheck = prefs.getString(KEY_LAST_CHECK, "");
        currentReportMarkdown = savedReport;

        if (!lastCheck.isEmpty()) {
            tvLastCheck.setText("Son Kontrol: " + lastCheck);
        }

        String html = MarkdownHtmlConverter.toStyledHtml(savedReport);
        reportWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    private void startBulletinGeneration() {
        String apiKey = prefs.getString(KEY_API, DEFAULT_API_KEY).trim();
        if (apiKey.isEmpty()) {
            Toast.makeText(this, "Lütfen Ayarlar'dan Gemini API anahtarınızı girin.", Toast.LENGTH_LONG).show();
            showSettingsDialog();
            return;
        }

        setLoadingState(true, "[1/2] Uzay kaynakları canlı taranıyor...");

        String todayStr = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        String startDate = getStartDate(todayStr);

        executor.execute(() -> {
            try {
                String liveFeeds = RssFetcher.fetchAllFeeds(10);

                mainHandler.post(() -> tvStatus.setText("[2/2] Yapay zeka ile bülten hazırlanıyor..."));

                String prompt = buildPrompt(startDate, todayStr, liveFeeds);
                GeminiClient.GenerationResult result = GeminiClient.generateBulletin(apiKey, prompt);

                String fullReport = "# 🚀 Uzay Bülteni (" + todayStr + ")\n\n"
                        + "> **Taranan Aralık:** `" + startDate + "` — `" + todayStr + "`  \n"
                        + "> **Model:** `" + result.modelUsed + "`\n\n"
                        + "---\n\n"
                        + result.text;

                String html = MarkdownHtmlConverter.toStyledHtml(fullReport);

                prefs.edit()
                        .putString(KEY_LAST_REPORT, fullReport)
                        .putString(KEY_LAST_CHECK, todayStr)
                        .apply();

                mainHandler.post(() -> {
                    currentReportMarkdown = fullReport;
                    tvLastCheck.setText("Son Kontrol: " + todayStr);
                    reportWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                    setLoadingState(false, "");
                    Toast.makeText(MainActivity.this, "Uzay Bülteni güncellendi!", Toast.LENGTH_SHORT).show();
                });

            } catch (Exception ex) {
                mainHandler.post(() -> {
                    setLoadingState(false, "");
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Hata Oluştu")
                            .setMessage("Bülten oluşturulurken hata oluştu:\n\n" + ex.getMessage())
                            .setPositiveButton("Tamam", null)
                            .show();
                });
            }
        });
    }

    private String getStartDate(String todayStr) {
        String saved = prefs.getString(KEY_LAST_CHECK, "");
        if (!saved.isEmpty() && saved.compareTo(todayStr) < 0) {
            return saved;
        }
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -7);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime());
    }

    private String buildPrompt(String startDate, String endDate, String liveData) {
        return "Sen uzman bir astronomi ve uzay bilimleri editörüsün.\n"
                + "**" + startDate + "** ile **" + endDate + "** tarihleri arasındaki güncel uzay ve astronomi gelişmelerini "
                + "değerlendirerek kapsamlı bir Türkçe **Uzay Bülteni** hazırla.\n\n"
                + "### Taranan Kaynaklar:\n"
                + "- https://www.nasa.gov/\n"
                + "- https://www.spacex.com/\n"
                + "- https://www.space.com/\n"
                + "- https://www.universetoday.com/\n"
                + "- https://uzay.org/\n"
                + "- https://evrimagaci.org/ (yalnızca uzay/astronomi)\n"
                + "- https://bilimgenc.tubitak.gov.tr/ (yalnızca uzay)\n\n"
                + "### Canlı Taranan Güncel Haber Verileri:\n"
                + (liveData.isEmpty() ? "Canlı haber akışı alınamadı, mevcut en güncel uzay bilgilerini kullan." : liveData)
                + "\n\n### Rapor Kuralları ve Yapısı:\n"
                + "1. **GÖK OLAYLARI (En Başta Olmalı):**\n"
                + "   Raporun en başına `## 🔭 GÖK OLAYLARI (Bu Hafta Gözlemlenebilecek Olaylar)` başlığı altında bu hafta "
                + "gökyüzünde gözlemlenebilecek önemli gök olaylarını (Ay evreleri, gezegen konumları, meteor yağmurları, "
                + "tutulmalar, ISS geçişleri vb.) tarihleriyle maddeler halinde ekle.\n\n"
                + "2. **HABERLERİN PUANLANMASI VE ⭐ İŞARETİ:**\n"
                + "   Her haberi önemine göre **1-10 arasında puanla** (`### ⭐ [9/10] Başlık...`). "
                + "Yüksek önemli konuların (8/10 ve üzeri) başlığının en başına mutlaka `⭐` koy ve en yüksek puandan en düşüğe sırala.\n\n"
                + "3. **TIKLANABİLİR KAYNAK LİNKLERİ:**\n"
                + "   Her haberin altında akıcı Türkçe özet, bilimsel önem ve mutlaka `[Kaynak Adı](URL)` şeklinde tıklanabilir Markdown bağlantısı yer alsın.\n"
                + "   `evrimagaci.org` ve `bilimgenc.tubitak.gov.tr` sitelerinden yalnızca uzay/astronomi içeriklerini ekle.";
    }

    private void setLoadingState(boolean loading, String status) {
        btnGenerate.setEnabled(!loading);
        btnGenerate.setAlpha(loading ? 0.6f : 1.0f);
        layoutProgress.setVisibility(loading ? View.VISIBLE : View.GONE);
        if (!status.isEmpty()) {
            tvStatus.setText(status);
        }
    }

    private void shareReport() {
        if (currentReportMarkdown == null || currentReportMarkdown.trim().isEmpty()) {
            Toast.makeText(this, "Paylaşılacak bir bülten henüz oluşturulmadı.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("text/plain");
        sendIntent.putExtra(Intent.EXTRA_SUBJECT, "Uzay Bülteni");
        sendIntent.putExtra(Intent.EXTRA_TEXT, currentReportMarkdown);
        startActivity(Intent.createChooser(sendIntent, "Uzay Bültenini Paylaş"));
    }

    private void showSettingsDialog() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        input.setText(prefs.getString(KEY_API, DEFAULT_API_KEY));
        input.setPadding(48, 32, 48, 32);

        new AlertDialog.Builder(this)
                .setTitle("⚙️ Gemini API Anahtarı")
                .setMessage("API anahtarınızı buradan güncelleyebilirsiniz:")
                .setView(input)
                .setPositiveButton("Kaydet", (dialog, which) -> {
                    String newKey = input.getText().toString().trim();
                    if (!newKey.isEmpty()) {
                        prefs.edit().putString(KEY_API, newKey).apply();
                        Toast.makeText(this, "API anahtarı kaydedildi.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("İptal", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }
}
