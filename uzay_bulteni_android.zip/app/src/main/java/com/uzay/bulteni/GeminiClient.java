package com.uzay.bulteni;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class GeminiClient {

    private static final String[] MODELS = new String[]{
            "gemini-3.1-flash-lite",
            "gemini-flash-latest",
            "gemini-3.8-flash",
            "gemini-3.5-flash"
    };

    public static class GenerationResult {
        public final String text;
        public final String modelUsed;

        public GenerationResult(String text, String modelUsed) {
            this.text = text;
            this.modelUsed = modelUsed;
        }
    }

    public static GenerationResult generateBulletin(String apiKey, String prompt) throws Exception {
        Exception lastError = null;

        for (String model : MODELS) {
            try {
                String responseText = callGeminiModel(apiKey, model, prompt);
                if (responseText != null && !responseText.trim().isEmpty()) {
                    return new GenerationResult(responseText.trim(), model);
                }
            } catch (Exception ex) {
                lastError = ex;
                // Sıradaki yedek modele geç
            }
        }

        if (lastError != null) {
            throw lastError;
        }
        throw new Exception("Gemini modellerinden yanıt alınamadı.");
    }

    private static String callGeminiModel(String apiKey, String model, String prompt) throws Exception {
        String endpoint = "https://generativelanguage.googleapis.com/v1beta/models/"
                + model + ":generateContent?key=" + apiKey.trim();

        URL url = new URL(endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(60000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

        JSONObject textPart = new JSONObject();
        textPart.put("text", prompt);

        JSONArray parts = new JSONArray();
        parts.put(textPart);

        JSONObject content = new JSONObject();
        content.put("parts", parts);

        JSONArray contents = new JSONArray();
        contents.put(content);

        JSONObject genConfig = new JSONObject();
        genConfig.put("temperature", 0.3);

        JSONObject payload = new JSONObject();
        payload.put("contents", contents);
        payload.put("generationConfig", genConfig);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
        }

        int statusCode = conn.getResponseCode();
        InputStream stream = statusCode >= 200 && statusCode < 300
                ? conn.getInputStream()
                : conn.getErrorStream();

        StringBuilder responseSb = new StringBuilder();
        if (stream != null) {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    responseSb.append(line);
                }
            }
        }
        conn.disconnect();

        String rawResponse = responseSb.toString();
        if (statusCode < 200 || statusCode >= 300) {
            throw new Exception("HTTP " + statusCode + " (" + model + "): " + rawResponse);
        }

        JSONObject json = new JSONObject(rawResponse);
        JSONArray candidates = json.optJSONArray("candidates");
        if (candidates != null && candidates.length() > 0) {
            JSONObject first = candidates.getJSONObject(0);
            JSONObject contentObj = first.optJSONObject("content");
            if (contentObj != null) {
                JSONArray respParts = contentObj.optJSONArray("parts");
                if (respParts != null && respParts.length() > 0) {
                    return respParts.getJSONObject(0).optString("text", "");
                }
            }
        }
        return "";
    }
}
