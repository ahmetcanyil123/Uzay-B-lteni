package com.uzay.bulteni;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class RssFetcher {

    private static class FeedSource {
        final String name;
        final String url;

        FeedSource(String name, String url) {
            this.name = name;
            this.url = url;
        }
    }

    private static final FeedSource[] SOURCES = new FeedSource[]{
            new FeedSource("NASA", "https://www.nasa.gov/feed/"),
            new FeedSource("Universe Today", "https://www.universetoday.com/feed/"),
            new FeedSource("Uzay.org", "https://uzay.org/feed/"),
            new FeedSource("Evrim Ağacı", "https://evrimagaci.org/rss.xml"),
            new FeedSource("SpaceX & Space.com",
                    "https://news.google.com/rss/search?q=site:spacex.com+OR+site:space.com+when:7d&hl=en-US&gl=US&ceid=US:en"),
            new FeedSource("TÜBİTAK Bilim Genç & Türkçe Uzay",
                    "https://news.google.com/rss/search?q=site:bilimgenc.tubitak.gov.tr+OR+site:uzay.org+OR+site:evrimagaci.org+uzay+astronomi&hl=tr&gl=TR&ceid=TR:tr")
    };

    public static String fetchAllFeeds(int maxPerFeed) {
        StringBuilder allItems = new StringBuilder();

        for (FeedSource source : SOURCES) {
            try {
                String xml = downloadString(source.url);
                if (xml != null && !xml.isEmpty()) {
                    List<String> parsed = parseRssItems(source.name, xml, maxPerFeed);
                    for (String item : parsed) {
                        allItems.append(item).append("\n\n");
                    }
                }
            } catch (Exception ignored) {
                // Bir kaynak geçici olarak erişilemezse diğer kaynaklarla devam et
            }
        }
        return allItems.toString().trim();
    }

    private static String downloadString(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 UzayBulteniAndroid/1.0");

        int code = conn.getResponseCode();
        if (code != HttpURLConnection.HTTP_OK) {
            return null;
        }

        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } finally {
            conn.disconnect();
        }
        return sb.toString();
    }

    private static List<String> parseRssItems(String sourceName, String xml, int maxItems) throws Exception {
        List<String> result = new ArrayList<>();
        XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
        factory.setNamespaceAware(false);
        XmlPullParser parser = factory.newPullParser();
        parser.setInput(new StringReader(xml));

        boolean insideItem = false;
        String title = "";
        String link = "";
        String pubDate = "";
        String description = "";

        int eventType = parser.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
            String tagName = parser.getName();

            if (eventType == XmlPullParser.START_TAG) {
                if ("item".equalsIgnoreCase(tagName)) {
                    insideItem = true;
                    title = "";
                    link = "";
                    pubDate = "";
                    description = "";
                } else if (insideItem) {
                    if ("title".equalsIgnoreCase(tagName)) {
                        title = safeNextText(parser);
                    } else if ("link".equalsIgnoreCase(tagName)) {
                        link = safeNextText(parser);
                    } else if ("pubDate".equalsIgnoreCase(tagName)) {
                        pubDate = safeNextText(parser);
                    } else if ("description".equalsIgnoreCase(tagName)) {
                        description = cleanHtml(safeNextText(parser));
                        if (description.length() > 300) {
                            description = description.substring(0, 300) + "...";
                        }
                    }
                }
            } else if (eventType == XmlPullParser.END_TAG && "item".equalsIgnoreCase(tagName)) {
                insideItem = false;
                if (!title.isEmpty()) {
                    result.add("- [" + sourceName + "] Başlık: " + title +
                            "\n  Tarih: " + pubDate +
                            "\n  Link: " + link +
                            "\n  Özet: " + description);
                    if (result.size() >= maxItems) {
                        break;
                    }
                }
            }
            eventType = parser.next();
        }
        return result;
    }

    private static String safeNextText(XmlPullParser parser) {
        try {
            String text = parser.nextText();
            return text != null ? text.trim() : "";
        } catch (Exception e) {
            return "";
        }
    }

    private static String cleanHtml(String input) {
        if (input == null) return "";
        return input.replaceAll("<[^>]*>", " ").replaceAll("\\s+", " ").trim();
    }
}
