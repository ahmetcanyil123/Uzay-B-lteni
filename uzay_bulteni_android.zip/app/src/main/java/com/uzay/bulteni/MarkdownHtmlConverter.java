package com.uzay.bulteni;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MarkdownHtmlConverter {

    private static final Pattern LINK_PATTERN = Pattern.compile("\\[([^\\]]+)\\]\\((https?://[^\\s)]+)\\)");
    private static final Pattern BOLD_PATTERN = Pattern.compile("\\*\\*([^*]+)\\*\\*");
    private static final Pattern ITALIC_PATTERN = Pattern.compile("(?<!\\*)\\*([^*]+)\\*(?!\\*)");
    private static final Pattern CODE_PATTERN = Pattern.compile("`([^`]+)`");

    public static String toStyledHtml(String markdown) {
        if (markdown == null || markdown.trim().isEmpty()) {
            return buildWelcomeHtml();
        }

        StringBuilder body = new StringBuilder();
        String[] lines = markdown.split("\\r?\\n");
        boolean inList = false;

        for (String rawLine : lines) {
            String line = rawLine.trim();

            if (line.isEmpty()) {
                if (inList) {
                    body.append("</ul>\n");
                    inList = false;
                }
                continue;
            }

            if (line.equals("---") || line.equals("***")) {
                if (inList) {
                    body.append("</ul>\n");
                    inList = false;
                }
                body.append("<hr/>\n");
                continue;
            }

            if (line.startsWith("### ")) {
                if (inList) {
                    body.append("</ul>\n");
                    inList = false;
                }
                body.append("<h3>").append(formatInline(line.substring(4))).append("</h3>\n");
            } else if (line.startsWith("## ")) {
                if (inList) {
                    body.append("</ul>\n");
                    inList = false;
                }
                body.append("<h2>").append(formatInline(line.substring(3))).append("</h2>\n");
            } else if (line.startsWith("# ")) {
                if (inList) {
                    body.append("</ul>\n");
                    inList = false;
                }
                body.append("<h1>").append(formatInline(line.substring(2))).append("</h1>\n");
            } else if (line.startsWith("* ") || line.startsWith("- ")) {
                if (!inList) {
                    body.append("<ul>\n");
                    inList = true;
                }
                body.append("<li>").append(formatInline(line.substring(2))).append("</li>\n");
            } else if (line.startsWith("> ")) {
                if (inList) {
                    body.append("</ul>\n");
                    inList = false;
                }
                body.append("<blockquote>").append(formatInline(line.substring(2))).append("</blockquote>\n");
            } else {
                if (inList) {
                    body.append("</ul>\n");
                    inList = false;
                }
                body.append("<p>").append(formatInline(line)).append("</p>\n");
            }
        }

        if (inList) {
            body.append("</ul>\n");
        }

        return wrapHtml(body.toString());
    }

    private static String formatInline(String text) {
        String escaped = text
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");

        // [Metin](URL) -> <a href="URL">Metin</a>
        Matcher linkMatcher = LINK_PATTERN.matcher(escaped);
        StringBuffer sbLink = new StringBuffer();
        while (linkMatcher.find()) {
            String label = linkMatcher.group(1);
            String url = linkMatcher.group(2);
            linkMatcher.appendReplacement(sbLink,
                    Matcher.quoteReplacement("<a href=\"" + url + "\">" + label + "</a>"));
        }
        linkMatcher.appendTail(sbLink);
        String result = sbLink.toString();

        // **kalın**
        result = BOLD_PATTERN.matcher(result).replaceAll("<strong>$1</strong>");
        // *italik*
        result = ITALIC_PATTERN.matcher(result).replaceAll("<em>$1</em>");
        // `kod`
        result = CODE_PATTERN.matcher(result).replaceAll("<code>$1</code>");

        return result;
    }

    private static String buildWelcomeHtml() {
        String welcome = "<div class='empty-box'>"
                + "<div class='planet'>🪐</div>"
                + "<h2>Uzay Bülteni Hazır</h2>"
                + "<p>Yukarıdaki <strong>\"⚡ Bülteni Oluştur / Canlı Tara\"</strong> butonuna dokunarak "
                + "NASA, SpaceX, Universe Today, Uzay.org, Evrim Ağacı ve TÜBİTAK Bilim Genç kaynaklarından "
                + "en güncel uzay ve astronomi haberlerini doğrudan burada okuyabilirsiniz.</p>"
                + "</div>";
        return wrapHtml(welcome);
    }

    private static String wrapHtml(String bodyContent) {
        return "<!DOCTYPE html>\n"
                + "<html lang=\"tr\">\n"
                + "<head>\n"
                + "<meta charset=\"utf-8\"/>\n"
                + "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"/>\n"
                + "<style>\n"
                + "  body { background:#090D16; color:#E2E8F0; font-family:-apple-system,Roboto,sans-serif; "
                + "         line-height:1.65; padding:14px 16px 40px 16px; margin:0; font-size:15px; }\n"
                + "  h1 { color:#38BDF8; font-size:20px; border-bottom:2px solid #1E293B; padding-bottom:8px; margin-top:4px; }\n"
                + "  h2 { color:#60A5FA; font-size:17px; margin-top:22px; margin-bottom:10px; }\n"
                + "  h3 { color:#F8FAFC; font-size:15.5px; background:#131A2A; padding:10px 12px; "
                + "       border-left:4px solid #F59E0B; border-radius:6px; margin-top:16px; }\n"
                + "  p { margin:8px 0; }\n"
                + "  ul { padding-left:20px; margin:8px 0 14px 0; }\n"
                + "  li { margin-bottom:8px; }\n"
                + "  a { color:#38BDF8; font-weight:600; text-decoration:underline; word-break:break-word; }\n"
                + "  code { background:#1E293B; color:#7DD3FC; padding:2px 5px; border-radius:4px; font-size:13px; }\n"
                + "  blockquote { background:#111827; border-left:4px solid #38BDF8; margin:12px 0; "
                + "               padding:10px 12px; color:#94A3B8; font-size:13.5px; border-radius:0 6px 6px 0; }\n"
                + "  hr { border:0; border-top:1px solid #1E293B; margin:18px 0; }\n"
                + "  .empty-box { text-align:center; padding:42px 18px; background:#111827; "
                + "               border:1px dashed #334155; border-radius:14px; margin-top:16px; }\n"
                + "  .planet { font-size:48px; margin-bottom:10px; }\n"
                + "</style>\n"
                + "</head>\n"
                + "<body>\n"
                + bodyContent
                + "\n</body>\n</html>";
    }
}
